# Organization Schema

Optional schema for an organization/service directory.

## Includes
- Content types: Organization, Service
- Taxonomy vocabulary: Tag
- Relationships
  - Service → Organization (`field_organization`)
  - Organization/Service → Tag (`field_tags`)

## CSV import
Includes Migrate Plus CSV migrations:
- Agencies → Organization (`hord_agencies`)
- Services → Service (`hord_services`) referencing Agencies

Place CSVs at `modules/custom/organization_schema/imports/` (or override with migrate configuration).
