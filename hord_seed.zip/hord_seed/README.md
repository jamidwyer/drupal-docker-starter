# Hord Seed

Drush command to generate safe demo data for Food + Organization schemas.

Run:
- drush hord:seed --profile=base
- drush hord:seed --profile=like-prod
- drush hord:seed --profile=base --seed=12345 --wipe
