<?php

namespace Drupal\hord_seed\Commands;

use Drush\Attributes as Drush;
use Drush\Commands\DrushCommands;
use Drupal\Core\Entity\EntityTypeManagerInterface;
use Drupal\node\NodeInterface;

final class HordSeedCommands extends DrushCommands {

  public function __construct(private readonly EntityTypeManagerInterface $entityTypeManager) {
    parent::__construct();
  }

  #[Drush\Command(name: 'hord:seed', aliases: ['hseed'])]
  #[Drush\Option(name: 'profile', description: 'Seed profile: base|like-prod', default: 'base')]
  #[Drush\Option(name: 'seed', description: 'Random seed for deterministic output', default: 12345)]
  #[Drush\Option(name: 'wipe', description: 'Delete previously seeded nodes (by tag) before seeding', default: false)]
  public function seed(array $options = ['profile' => 'base', 'seed' => 12345, 'wipe' => false]): void {
    $profile = (string) $options['profile'];
    $seed = (int) $options['seed'];
    $wipe = (bool) $options['wipe'];

    mt_srand($seed);

    $counts = match ($profile) {
      'like-prod' => [
        'tags' => 30,
        'orgs' => 25,
        'services' => 250,
        'units' => 20,
        'ingredients' => 200,
        'products' => 400,
        'inventories' => 600,
      ],
      default => [
        'tags' => 10,
        'orgs' => 5,
        'services' => 25,
        'units' => 8,
        'ingredients' => 40,
        'products' => 60,
        'inventories' => 80,
      ],
    };

    if ($wipe) {
      $this->wipeSeededContent();
    }

    $tags = $this->ensureTags($counts['tags']);
    $orgs = $this->createOrganizations($counts['orgs'], $tags);
    $this->createServices($counts['services'], $orgs, $tags);

    $units = $this->createUnits($counts['units']);
    $ingredients = $this->createIngredients($counts['ingredients']);
    $products = $this->createProducts($counts['products'], $ingredients);
    $this->createInventories($counts['inventories'], $products, $units);

    $this->logger()->success(sprintf(
      'Seeded (%s) with seed=%d: %d orgs, %d services, %d products, %d inventories.',
      $profile,
      $seed,
      $counts['orgs'],
      $counts['services'],
      $counts['products'],
      $counts['inventories'],
    ));
  }

  private function wipeSeededContent(): void {
    $storage = $this->entityTypeManager->getStorage('node');
    $nids = $storage->getQuery()
      ->accessCheck(false)
      ->condition('title', 'Seed ', 'STARTS_WITH')
      ->execute();
    if (!$nids) {
      $this->logger()->notice('No seeded nodes found to delete.');
      return;
    }
    $nodes = $storage->loadMultiple($nids);
    $storage->delete($nodes);
    $this->logger()->notice(sprintf('Deleted %d seeded nodes.', count($nids)));
  }

  /** @return int[] term IDs */
  private function ensureTags(int $count): array {
    $storage = $this->entityTypeManager->getStorage('taxonomy_term');
    $tids = [];

    // Create predictable tag names.
    for ($i = 1; $i <= $count; $i++) {
      $name = sprintf('Tag %02d', $i);
      $existing = $storage->getQuery()
        ->accessCheck(false)
        ->condition('vid', 'tag')
        ->condition('name', $name)
        ->range(0, 1)
        ->execute();
      if ($existing) {
        $tids[] = (int) array_values($existing)[0];
        continue;
      }
      $term = $storage->create([
        'vid' => 'tag',
        'name' => $name,
      ]);
      $term->save();
      $tids[] = (int) $term->id();
    }

    return $tids;
  }

  /** @param int[] $tagTids */
  private function createOrganizations(int $count, array $tagTids): array {
    $nodes = [];
    for ($i = 1; $i <= $count; $i++) {
      $nodes[] = $this->createNode('organization', [
        'title' => sprintf('Seed Organization %02d', $i),
        'field_tags' => $this->pickMany($tagTids, mt_rand(0, 3)),
        'body' => [
          'value' => $this->lorem(mt_rand(40, 120)),
          'format' => 'basic_html',
        ],
      ]);
    }
    return $nodes;
  }

  /** @param NodeInterface[] $orgs @param int[] $tagTids */
  private function createServices(int $count, array $orgs, array $tagTids): void {
    for ($i = 1; $i <= $count; $i++) {
      $org = $orgs[array_rand($orgs)];
      $this->createNode('service', [
        'title' => sprintf('Seed Service %03d', $i),
        'field_organization' => ['target_id' => $org->id()],
        'field_tags' => $this->pickMany($tagTids, mt_rand(0, 3)),
        'body' => [
          'value' => $this->lorem(mt_rand(60, 180)),
          'format' => 'basic_html',
        ],
      ]);
    }
  }

  /** @return NodeInterface[] */
  private function createUnits(int $count): array {
    $abbrs = ['g','kg','oz','lb','ml','l','tsp','tbsp','cup','pinch','dash','each','slice','can','pkg','bunch','clove','piece','serving'];
    $nodes = [];
    for ($i = 1; $i <= $count; $i++) {
      $abbr = $abbrs[($i - 1) % count($abbrs)];
      $nodes[] = $this->createNode('quantitative_unit', [
        'title' => 'Seed ' . strtoupper($abbr),
        'field_abbreviation' => $abbr,
      ]);
    }
    return $nodes;
  }

  /** @return NodeInterface[] */
  private function createIngredients(int $count): array {
    $base = ['Onion','Garlic','Tomato','Carrot','Celery','Lemon','Lime','Ginger','Basil','Cilantro','Parsley','Rice','Beans','Pasta','Olive Oil','Butter','Milk','Cheddar','Egg','Flour','Sugar','Salt','Pepper','Cumin','Paprika','Chicken','Tofu','Yogurt','Spinach','Potato'];
    $nodes = [];
    for ($i = 1; $i <= $count; $i++) {
      $name = $base[array_rand($base)] . (mt_rand(0, 9) === 0 ? (' ' . chr(65 + ($i % 26))) : '');
      $nodes[] = $this->createNode('ingredient', [
        'title' => 'Seed ' . $name,
      ]);
    }
    return $nodes;
  }

  /** @param NodeInterface[] $ingredients @return NodeInterface[] */
  private function createProducts(int $count, array $ingredients): array {
    $nodes = [];
    for ($i = 1; $i <= $count; $i++) {
      $ings = $this->pickMany(array_map(fn($n) => $n->id(), $ingredients), mt_rand(0, 6));
      $nodes[] = $this->createNode('product', [
        'title' => sprintf('Seed Product %03d', $i),
        'field_ingredients' => array_map(fn($id) => ['target_id' => $id], $ings),
      ]);
    }
    return $nodes;
  }

  /** @param NodeInterface[] $products @param NodeInterface[] $units */
  private function createInventories(int $count, array $products, array $units): void {
    for ($i = 1; $i <= $count; $i++) {
      $product = $products[array_rand($products)];
      $unit = $units[array_rand($units)];
      $amount = round((mt_rand(1, 5000) / 100), 3);

      $quantity = $this->createNode('quantity', [
        'title' => sprintf('Seed %s %s', $amount, $unit->label()),
        'field_amount' => $amount,
        'field_unit' => ['target_id' => $unit->id()],
      ]);

      $this->createNode('inventory', [
        'title' => sprintf('Seed Inventory %03d', $i),
        'field_product' => ['target_id' => $product->id()],
        'field_quantity' => ['target_id' => $quantity->id()],
      ]);
    }
  }

  private function createNode(string $type, array $fields): NodeInterface {
    $storage = $this->entityTypeManager->getStorage('node');
    $values = array_merge(['type' => $type], $fields);
    $node = $storage->create($values);
    $node->save();
    return $node;
  }

  /** @return array */
  private function pickMany(array $values, int $count): array {
    if ($count <= 0 || !$values) {
      return [];
    }
    $count = min($count, count($values));
    $keys = array_rand($values, $count);
    if (!is_array($keys)) {
      $keys = [$keys];
    }
    return array_values(array_map(fn($k) => $values[$k], $keys));
  }

  private function lorem(int $words): string {
    $pool = explode(' ', 'lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua ut enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non proident sunt in culpa qui officia deserunt mollit anim id est laborum');
    $out = [];
    for ($i = 0; $i < $words; $i++) {
      $out[] = $pool[array_rand($pool)];
    }
    return ucfirst(implode(' ', $out)) . '.';
  }

}
